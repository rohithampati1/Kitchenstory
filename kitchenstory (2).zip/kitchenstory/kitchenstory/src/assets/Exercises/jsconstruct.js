//Conditional Constructs /Looping Constructs
//global 
var glb = 1;

function WhileLoop() {
    //Looping constructs
    //while loop
    console.log(glb);
    var n1 = 0;
    console.log("While loop");
    while (n1 < 10) {
        console.log("n1 -> " + n1);
        n1++;
        if (n1 == 6)
            continue;
        // break;
        console.log("Inside while loop");
    }

    var n2 = 1;
    console.log("Do While loop");
    do {
        console.log("inside the do loop")

    } while (n2 > 10)

}

function ForLoop() {
    console.log(n1);
    console.log("For loop");
    var i = 0;
    for (; i < 5;) {
        console.log("i -> " + i);
        i++;
    }
}

function IfConstruct() {
    var custname;
    var age = 0;

    custname = prompt("Enter your user name pls");
    age = prompt("Enter your age pls");

    //if-else-if ladder
    if (age >= 18 && age <= 59) {
        alert("Hello " + custname + "You are eligible to vote..");
        console.log(custname);
    }

    else if (age > 60) {
        alert("Retiring age...");
    }

    else {
        alert("Not eligible to vote")
    }


    //nested if
    //outer if

    if (custname == "cust1") {
        alert("Hey! " + custname);
        var pwd = prompt("Password pls?");
        //inner if construct
        if (pwd == "1234") {
            alert("Welcome to Softbank ATM!");

        }
        else {
            alert("Sorry pass not valid");
        }

    }
    else {
        alert("Your cust name is not valid");
    }

}

function SwitchConstruct() {

    var bookchoice = prompt("Which is your Favorite book? 1.LOTR 2.HarryPotter 3.PercyJackson", 1);
    switch (bookchoice) {
        case "1":
            console.log("Your choice of Novel is " + "LOTR");
            console.log("Lord of the Rings");
            IfConstruct();
            break;

        case "2":
            console.log("Your choice of Novel is " + "HP");
            break;

        case "3":
            console.log("Your choice of Novel is " + "PJ");
            break;

        default:
            break;
    }

}



