//Declaring+Initializing Variable
var name = "Lavan";
var age, city, state = 0;

// Display functions
// alert("From the external script file.. name1 " + name);
// //reinitialization
// name = 10;
// console.log("Printing in the console.. name2" + name);
// document.write("Printing on the page..");
// name = prompt("Enter your Name?");
// console.log(name);

var num1 = 10;
var num2 = 20;
var add = num1 + num2;

//operators
console.log("Addition of " + typeof (num1) + typeof (num2) + add);

num1 = prompt("Enter first number");
num2 = prompt("Enter second number");

//conversions - parseInt/eval/+
var add = +num1 + +num2;
console.log("Addition of " + typeof (num1) + " " + typeof (num2) + add);

//relational > < >= <=
console.log("Number1 is greater than number2" + (num1 > num2));

//Assignment = equality ==  strict equality ===
num2 = parseInt(num2);
console.log("Type of " + typeof (num1) + typeof (num2));
console.log("num1 equality to num2 is " + (num1 === num2));

//unary
num2++;
console.log(num2);

// compound operator
num2 -= 5;
console.log(num2);