import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutsample',
  templateUrl: './aboutsample.component.html',
  styleUrls: ['./aboutsample.component.css']
})
export class AboutsampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
