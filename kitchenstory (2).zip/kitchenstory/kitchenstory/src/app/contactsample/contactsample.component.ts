import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contactsample',
  templateUrl: './contactsample.component.html',
  styleUrls: ['./contactsample.component.css']
})
export class ContactsampleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
