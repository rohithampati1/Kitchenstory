export class Item1
{
constructor(
    public fruitid="",
    public fruitname="",
    public fruitcost="",
    public fruitimg="",
    public fruitquantity="",
    public fruittotal=""

){}
}